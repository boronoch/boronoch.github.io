import sqlite3
import os
from datetime import date, timedelta
from flask import g, current_app

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db(app):
    db_path = app.config["DATABASE"]
    is_new = not os.path.exists(db_path)
    conn = sqlite3.connect(db_path)
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    with open(schema_path, "r") as f:
        conn.executescript(f.read())
    conn.execute(
        "INSERT OR IGNORE INTO settings (id, plan_start_hour, plan_end_hour, slots_per_day) "
        "VALUES (1, 5.0, 21.0, 32)"
    )
    conn.execute(
        "INSERT OR IGNORE INTO routine_state (id, date, selected_column, checks_json) "
        "VALUES (1, '1970-01-01', 'Monday', '{}')"
    )
    conn.commit()
    run_data_migrations(conn)
    conn.close()
    return is_new


def run_data_migrations(conn):
    """Small, idempotent one-off data fixes. Safe to run on every startup -
    each one only acts if its old state still exists."""
    category_renames = [
        ("Errands", "Errands, Appts"),
    ]
    for old_name, new_name in category_renames:
        conn.execute("UPDATE category SET name=? WHERE name=?", (new_name, old_name))
        conn.execute(
            "UPDATE cycle_item SET category_name=? WHERE category_name=?",
            (new_name, old_name),
        )
    # Cycle items migrated from Excel have no priority; fill from the live item list.
    conn.execute(
        "UPDATE cycle_item SET priority = COALESCE("
        "(SELECT i.priority FROM item i WHERE i.id = cycle_item.source_item_id), "
        "(SELECT i.priority FROM item i WHERE i.description = cycle_item.description LIMIT 1)) "
        "WHERE priority IS NULL OR priority = ''"
    )
    conn.commit()


def slot_time_label(slot_index, plan_start_hour=5.0):
    total_minutes = int(plan_start_hour * 60) + slot_index * 30
    hour24 = (total_minutes // 60) % 24
    minute = total_minutes % 60
    suffix = "AM" if hour24 < 12 else "PM"
    hour12 = hour24 % 12
    if hour12 == 0:
        hour12 = 12
    return f"{hour12}:{minute:02d} {suffix}"


def register_db(app):
    app.teardown_appcontext(close_db)


def cycle_date(cycle_row, week_number, day_of_week):
    """Real calendar date for a given week/day within a cycle, or None if
    the cycle has no start_date set."""
    if not cycle_row["start_date"]:
        return None
    start = date.fromisoformat(cycle_row["start_date"])
    return start + timedelta(days=(week_number - 1) * 7 + day_of_week)


def today_week_day(cycle_row, today=None):
    """Given a cycle, return (week_number, day_of_week) that today falls
    into, or None if the cycle has no start_date or today is outside its
    4-week range."""
    if not cycle_row["start_date"]:
        return None
    today = today or date.today()
    start = date.fromisoformat(cycle_row["start_date"])
    delta = (today - start).days
    if delta < 0 or delta >= 28:
        return None
    return (delta // 7 + 1, delta % 7)

